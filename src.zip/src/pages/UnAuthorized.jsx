const UnAuthorized = () => {
  return <h1>Unauthorized</h1>;
};

export { UnAuthorized };
